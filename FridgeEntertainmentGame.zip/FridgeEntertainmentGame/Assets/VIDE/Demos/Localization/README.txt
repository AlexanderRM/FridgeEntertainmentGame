This example covers Localization and a different UI manager setup that uses no components.
Check the Canvas and Button game objects.
