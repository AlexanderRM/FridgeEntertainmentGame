This example Uses the VD2 class to create multiple instances of dialogue data.
Check the Canvas and Button game objects.
