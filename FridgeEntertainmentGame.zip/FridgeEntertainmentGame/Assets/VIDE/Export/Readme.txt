Dialogues you export to text files will be stored here. 
When importing the text files, VIDE will look in this folder, so make sure they are here.
Always make sure the file name matches with the dialogue name you are importing into. 